# -*- coding: utf-8 -*-
"""
RemGruz — «ТО парка»: мобильное приложение для механиков.
Blueprint для сервера RG1Tech (Flask + gunicorn).

Подключение в app.py (2 строки):

    from to_module import create_to_blueprint, start_to_notifier
    app.register_blueprint(create_to_blueprint(
        fetch_to=<функция, которая возвращает dict как /api/a1track/to>,
        fetch_fleet=<функция, которая возвращает dict как /api/omnicomm/fleet>,
    ))
    start_to_notifier()   # фоновая проверка порогов каждые 30 минут

`fetch_to` / `fetch_fleet` — те же функции, которыми уже пользуются
эндпоинты /api/a1track/to и /api/omnicomm/fleet (без Flask-обёртки).

Оповещения: за SOON_KM (5 000 км) до ТО и в момент наступления (км <= 0).
Каналы: Web Push (нужен HTTPS! см. INSTALL.md) и/или Telegram (работает сразу).

ENV (все опциональны):
    TO_VAPID_PUBLIC, TO_VAPID_PRIVATE, TO_VAPID_EMAIL   — ключи Web Push
    TO_TG_BOT_TOKEN, TO_TG_CHAT_ID                      — Telegram-канал оповещений
    TO_DATA_DIR                                          — куда писать журнал/подписки (default: ./to_data)
"""

import json
import os
import re
import threading
import time
import urllib.request
from datetime import datetime
from pathlib import Path

from flask import Blueprint, jsonify, request, send_from_directory

SOON_KM = 5000.0
CHECK_INTERVAL_SEC = 30 * 60
WORK_LABELS = {
    "Масло": "ТО малое (масло)",
    "Коробка и редуктор": "ТО большое (коробка и редуктор)",
    "Регулировка клапанов": "Регулировка клапанов",
}
RESET_HYSTERESIS_KM = SOON_KM + 2000  # отметка «отправлено» сбрасывается после ТО (ресурс снова вырос)

DATA_DIR = Path(os.environ.get("TO_DATA_DIR", Path(__file__).parent / "to_data"))
STATIC_DIR = Path(__file__).parent / "static"
LOG_FILE = DATA_DIR / "to_log.json"
SUBS_FILE = DATA_DIR / "push_subscriptions.json"
STATE_FILE = DATA_DIR / "notify_state.json"

_lock = threading.Lock()
_fetch_to = None
_fetch_fleet = None

LAT2CYR = str.maketrans("abcehkmoptxy", "авсенкмортху")


# ─────────────────────────── helpers ───────────────────────────

def _load(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save(path, data):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)


def parse_km(text):
    """'8 211,6 км' -> 8211.6 · '-7,2 км' -> -7.2 · не-км -> None"""
    if not isinstance(text, str) or "км" not in text:
        return None
    try:
        return float(re.sub(r"[^\d,.\-]", "", text).replace(",", "."))
    except ValueError:
        return None


def series_of(car_number):
    m = re.match(r"^([а-я])(\d{3})([а-я]{2})", (car_number or "").lower().translate(LAT2CYR))
    return "".join(m.groups()) if m else (car_number or "").lower()


# ─────────────────────────── blueprint ───────────────────────────

def create_to_blueprint(fetch_to, fetch_fleet):
    global _fetch_to, _fetch_fleet
    _fetch_to, _fetch_fleet = fetch_to, fetch_fleet

    bp = Blueprint("to_app", __name__)

    # — приложение (без авторизации — по решению владельца) —
    @bp.route("/to")
    @bp.route("/to/")
    def to_index():
        return send_from_directory(STATIC_DIR, "index.html")

    @bp.route("/to/<path:fname>")
    def to_static(fname):
        return send_from_directory(STATIC_DIR, fname)

    # — публичные данные для приложения —
    @bp.route("/api/to/public")
    def to_public():
        try:
            to_data = _fetch_to()
            fleet = _fetch_fleet()
        except Exception as e:
            return jsonify(ok=False, error=str(e)), 502
        return jsonify(ok=True, to=to_data, fleet=fleet,
                       updated=datetime.now().strftime("%d.%m.%Y %H:%M"))

    # — журнал отметок «ТО сделано» —
    @bp.route("/api/to/log", methods=["GET", "POST"])
    def to_log():
        with _lock:
            log = _load(LOG_FILE, [])
            if request.method == "POST":
                e = request.get_json(silent=True) or {}
                entry = {k: e.get(k) for k in
                         ("car", "work", "date", "date_h", "mileage", "author", "comment", "ts")}
                if not entry["car"] or not entry["work"]:
                    return jsonify(ok=False, error="car and work required"), 400
                entry["received"] = datetime.now().isoformat(timespec="seconds")
                # дедупликация по (car, work, ts)
                if not any(x.get("car") == entry["car"] and x.get("work") == entry["work"]
                           and x.get("ts") == entry["ts"] for x in log):
                    log.append(entry)
                    _save(LOG_FILE, log[-2000:])
                return jsonify(ok=True)
            car = request.args.get("car")
            rows = [x for x in log if not car or x.get("car") == car]
            return jsonify(ok=True, rows=rows[-200:])

    # — push-подписки —
    @bp.route("/api/to/push/vapid")
    def push_vapid():
        pub = os.environ.get("TO_VAPID_PUBLIC", "")
        if not pub:
            return jsonify(ok=False, error="VAPID not configured"), 503
        return jsonify(ok=True, publicKey=pub)

    @bp.route("/api/to/push/subscribe", methods=["POST"])
    def push_subscribe():
        sub = request.get_json(silent=True)
        if not sub or "endpoint" not in sub:
            return jsonify(ok=False, error="bad subscription"), 400
        with _lock:
            subs = _load(SUBS_FILE, [])
            if not any(s.get("endpoint") == sub["endpoint"] for s in subs):
                subs.append(sub)
                _save(SUBS_FILE, subs)
        return jsonify(ok=True)

    @bp.route("/api/to/push/unsubscribe", methods=["POST"])
    def push_unsubscribe():
        ep = (request.get_json(silent=True) or {}).get("endpoint")
        with _lock:
            subs = [s for s in _load(SUBS_FILE, []) if s.get("endpoint") != ep]
            _save(SUBS_FILE, subs)
        return jsonify(ok=True)

    return bp


# ─────────────────────────── оповещения ───────────────────────────

def _send_web_push(payload):
    """Рассылка всем подписчикам. Требует pywebpush и VAPID-ключи."""
    priv = os.environ.get("TO_VAPID_PRIVATE")
    if not priv:
        return 0
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        return 0
    email = os.environ.get("TO_VAPID_EMAIL", "mailto:tehdir@dlsgroup.su")
    with _lock:
        subs = _load(SUBS_FILE, [])
    alive, sent = [], 0
    for sub in subs:
        try:
            webpush(subscription_info=sub, data=json.dumps(payload, ensure_ascii=False),
                    vapid_private_key=priv, vapid_claims={"sub": email})
            alive.append(sub)
            sent += 1
        except WebPushException as e:
            code = getattr(getattr(e, "response", None), "status_code", None)
            if code not in (404, 410):      # мёртвые подписки выкидываем
                alive.append(sub)
        except Exception:
            alive.append(sub)
    with _lock:
        _save(SUBS_FILE, alive)
    return sent


def _send_telegram(text):
    token = os.environ.get("TO_TG_BOT_TOKEN")
    chat = os.environ.get("TO_TG_CHAT_ID")
    if not token or not chat:
        return False
    try:
        body = json.dumps({"chat_id": chat, "text": text, "parse_mode": "HTML"}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage",
            data=body, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=15)
        return True
    except Exception:
        return False


def check_and_notify():
    """Одна проверка порогов. Вызывается по расписанию (или руками для теста)."""
    if _fetch_to is None:
        return {"error": "blueprint not initialized"}
    try:
        to_data = _fetch_to()
    except Exception as e:
        return {"error": f"fetch_to failed: {e}"}

    state = _load(STATE_FILE, {})     # {"Т358РТ797|Масло": {"stage": "soon"|"due", "km": ...}}
    events = []

    for row in to_data.get("rows", []):
        num = row.get("car_number", "?")
        model = row.get("car_model", "")
        for work, cell in (row.get("cells") or {}).items():
            km = parse_km(cell.get("next_text", ""))
            if km is None:
                continue
            key = f"{num}|{work}"
            prev = state.get(key, {})
            stage = prev.get("stage")

            if km <= 0 and stage != "due":
                state[key] = {"stage": "due", "km": km, "at": datetime.now().isoformat()}
                events.append(("due", num, model, work, km))
            elif 0 < km <= SOON_KM and stage not in ("soon", "due"):
                state[key] = {"stage": "soon", "km": km, "at": datetime.now().isoformat()}
                events.append(("soon", num, model, work, km))
            elif km > RESET_HYSTERESIS_KM and stage:
                state.pop(key, None)   # ТО сделали, ресурс вырос — взводим порог заново

    _save(STATE_FILE, state)

    sent = {"push": 0, "telegram": 0}
    for kind, num, model, work, km in events:
        series = series_of(num).upper()
        label = WORK_LABELS.get(work, work)
        if kind == "due":
            title = "🔴 ТО наступило"
            body = f"{series} ({model}) — {label}: перепробег {abs(km):,.0f} км. Ставь в цех.".replace(",", " ")
        else:
            title = "🟡 Скоро ТО"
            body = f"{series} ({model}) — {label}: осталось {km:,.0f} км (порог 5 000).".replace(",", " ")
        sent["push"] += _send_web_push({"title": title, "body": body,
                                        "tag": f"to-{series}-{work}", "url": "/to"})
        if _send_telegram(f"<b>{title}</b>\n{body}"):
            sent["telegram"] += 1

    return {"events": len(events), "sent": sent}


def start_to_notifier(interval_sec=CHECK_INTERVAL_SEC):
    """Фоновый поток проверки порогов. Вызвать один раз после register_blueprint."""
    def loop():
        time.sleep(60)          # даём серверу подняться
        while True:
            try:
                check_and_notify()
            except Exception:
                pass
            time.sleep(interval_sec)

    t = threading.Thread(target=loop, daemon=True, name="to-notifier")
    t.start()
    return t
