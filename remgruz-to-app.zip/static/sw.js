/* RemGruz — ТО парка · service worker: offline-оболочка + push */
const CACHE = 'to-app-v1';
const SHELL = ['index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* Оболочка — cache-first; данные /api/ — только сеть (свежесть важнее) */
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.pathname.includes('/api/')) return;
  e.respondWith(
    caches.match(e.request, {ignoreSearch: true}).then(hit =>
      hit || fetch(e.request).then(resp => {
        if (resp.ok && e.request.method === 'GET' && url.origin === location.origin) {
          const copy = resp.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return resp;
      })
    ).catch(() => caches.match('index.html'))
  );
});

/* Push: {title, body, tag, url} */
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data.json(); } catch (_) { d = {body: e.data && e.data.text()}; }
  e.waitUntil(self.registration.showNotification(d.title || 'ТО парка — RemGruz', {
    body: d.body || '',
    tag: d.tag || 'to-alert',
    renotify: true,
    icon: 'icon-192.png',
    badge: 'icon-192.png',
    data: {url: d.url || './'},
    vibrate: [180, 80, 180]
  }));
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.matchAll({type: 'window', includeUncontrolled: true}).then(list => {
    for (const c of list) if ('focus' in c) return c.focus();
    return clients.openWindow(e.notification.data.url || './');
  }));
});
