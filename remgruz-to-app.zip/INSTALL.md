# ТО парка — установка на сервер RG1Tech

Мобильное приложение для механиков: остаток до ТО в **км и %**, прогноз даты заезда,
статус машины из Omnicomm, отметки «ТО сделано», оповещения за 5 000 км и при наступлении ТО.

Показывать эту инструкцию Claude в RG1Tech-сессии — он всё сделает по ней сам.

## 1. Файлы

Скопировать в каталог проекта RG1Tech (рядом с app.py):

```
to_module.py
static/            → положить как  to_static/  или оставить рядом: to_module.py ищет ./static
  index.html
  sw.js
  manifest.webmanifest
  icon-192.png
  icon-512.png
```

Если каталог `static` уже занят Flask'ом — переименуй папку в `to_static`
и поправь в `to_module.py` строку `STATIC_DIR = Path(__file__).parent / "static"`.

## 2. Подключение (app.py)

```python
from to_module import create_to_blueprint, start_to_notifier

# fetch_to / fetch_fleet — те ЖЕ функции, которые уже кормят
# /api/a1track/to и /api/omnicomm/fleet (внутренние, без Flask-обёртки).
app.register_blueprint(create_to_blueprint(
    fetch_to=get_a1track_to_data,      # ← подставить реальное имя
    fetch_fleet=get_omnicomm_fleet,    # ← подставить реальное имя
))
start_to_notifier()    # проверка порогов каждые 30 минут
```

Если внутренние функции неудобно достать — временный вариант: обёртки, которые дергают
существующие view-функции напрямую (`.get_json()` от `test_request_context`), но лучше первый путь.

Перезапустить gunicorn. Проверка:

* `http://194.87.161.37:3000/to` — приложение открывается, данные живые (зелёная точка «Live»)
* `http://194.87.161.37:3000/api/to/public` — JSON с `to` и `fleet`

## 3. Доступ сотрудников

Раздать ссылку `http://194.87.161.37:3000/to`.
Android/Chrome: меню → «Добавить на главный экран». iPhone/Safari: «Поделиться» → «На экран Домой».

⚠️ Страница и API `/api/to/*` открыты без авторизации — осознанное решение владельца.
Если передумаешь: самый дешёвый вариант — ключ в ссылке (`/to?key=...`, проверка в blueprint, механикам выслать готовую ссылку один раз).

## 4. Оповещения

Логика уже в `to_module.py` (`check_and_notify`): за **5 000 км** до ТО и **при наступлении** (км ≤ 0).
Повторных спам-уведомлений нет: каждый порог срабатывает один раз и взводится заново после выполнения ТО.
Каналы — какие настроены (можно оба):

### 4а. Web Push (выбор владельца; требует HTTPS)

Браузеры разрешают push **только на HTTPS** — на `http://194.87.161.37:3000` работать не будет.
Самый короткий путь к HTTPS:

1. Поддомен, например `to.dlsgroup.su` → A-запись на `194.87.161.37`
2. На сервер поставить **Caddy** (автоматический Let's Encrypt):
   ```
   # /etc/caddy/Caddyfile
   to.dlsgroup.su {
       reverse_proxy 127.0.0.1:3000
   }
   ```
   `apt install caddy && systemctl enable --now caddy` — сертификат подхватится сам.
3. Ключи VAPID:
   ```bash
   pip install pywebpush
   vapid --gen        # выдаст public/private ключи
   ```
4. В окружение gunicorn (systemd unit / .env):
   ```
   TO_VAPID_PUBLIC=BM...   TO_VAPID_PRIVATE=...   TO_VAPID_EMAIL=mailto:tehdir@dlsgroup.su
   ```
5. Открыть `https://to.dlsgroup.su/to`, нажать колокольчик, разрешить уведомления.
   iPhone: сначала добавить на экран «Домой», уведомления работают из установленного приложения (iOS 16.4+).

### 4б. Telegram (работает сразу, HTTPS не нужен — рекомендую включить как минимум до HTTPS)

1. @BotFather → `/newbot` → получить токен
2. Создать группу «РемГруз · ТО», добавить бота, узнать chat_id
   (переслать любое сообщение группы боту @getidsbot, id вида `-100...`)
3. В окружение:
   ```
   TO_TG_BOT_TOKEN=123456:AA...   TO_TG_CHAT_ID=-100...
   ```

### Проверка оповещений вручную

```python
python3 -c "import to_module; to_module._fetch_to = <функция>; print(to_module.check_and_notify())"
```
или временно уменьшить `CHECK_INTERVAL_SEC`. Состояние порогов — `to_data/notify_state.json`
(удалить файл = все пороги взведутся заново).

## 5. Что где лежит

```
to_data/to_log.json             журнал отметок «ТО сделано»
to_data/push_subscriptions.json push-подписки
to_data/notify_state.json       какие пороги уже отправлены
```

## 6. Демо без сервера

`RemGruz-TO-demo.html` — тот же интерфейс со встроенным снимком данных от 12.07.2026.
Открывается где угодно (телефон/комп), помечен жёлтой точкой «Демо-режим».
